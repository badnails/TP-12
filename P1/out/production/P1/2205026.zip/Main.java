import UserInterface.UI;

public class Main {
    public static void main(String[] args) throws Exception{
        UI io = new UI();
        io.program();
    }
}
